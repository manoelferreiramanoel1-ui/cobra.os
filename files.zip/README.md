# Cobra O.S — Expresso Nepomuceno

Controle de retiradas de peças sem O.S. no almoxarifado. Aplicativo web (PWA-ready) em arquivo único, sem servidor e sem instalação.

## Como publicar no GitHub
1. Crie um repositório e envie `index.html`, `assets/logo.jpg` e este `README.md`.
2. Em **Settings → Pages**, escolha a branch `main` e a pasta `/ (root)`.
3. Abra o endereço gerado (`https://SEU-USUARIO.github.io/NOME-DO-REPO/`) no celular ou computador.

## Dados
Ficam salvos **no próprio aparelho** (IndexedDB) — cada celular/navegador tem os seus registros.
Use **Configurações → Baixar backup** com frequência. Nada é enviado ao GitHub.
Para uso compartilhado entre vários almoxarifes, o próximo passo é um backend com banco (Python + SQLite ou similar).

## Como as telas se conectam
Mecânico → Retirada (várias peças) → Cobrança (marca como EM COBRANÇA) → Informar O.S. (REGULARIZADA) → Dashboard e Relatórios.
Todo evento grava histórico (quem, quando, o quê); nada é excluído — só cancelamento com justificativa.
